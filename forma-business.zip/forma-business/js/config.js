// Public Supabase settings. Only the PUBLIC "anon" key belongs here.
// NEVER put the service_role key in any frontend file.
// Supabase Dashboard -> Project Settings -> API
window.FORMA_CONFIG = {
  SUPABASE_URL: 'https://YOUR-PROJECT-ref.supabase.co',
  SUPABASE_ANON_KEY: 'YOUR-PUBLIC-ANON-KEY',
  CURRENCY: 'INR',
  LOCALE: 'en-IN',
  PAGE_SIZE: 25
};
