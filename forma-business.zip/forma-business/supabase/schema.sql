-- =====================================================================
-- FORMA COSMETICS - Business Management
-- Supabase / PostgreSQL schema  (run in Supabase SQL Editor)
-- Phase 1: tables, indexes, triggers, invoice numbering, RLS, storage
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------
create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- Human-readable IDs (CUST-0001, PRD-0001 ...)
create sequence if not exists seq_customer start 1;
create sequence if not exists seq_product  start 1;
create sequence if not exists seq_expense  start 1;
create sequence if not exists seq_investment start 1;
create sequence if not exists seq_production start 1;

-- ---------------------------------------------------------------------
-- profiles  (1:1 with auth.users)
-- ---------------------------------------------------------------------
create table public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text,
  email       text,
  phone       text,
  role        text not null default 'staff' check (role in ('admin','staff')),
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create or replace function public.current_role_name() returns text
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid() and is_active
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.current_role_name() = 'admin', false)
$$;

create or replace function public.is_staff_or_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.current_role_name() in ('admin','staff'), false)
$$;

-- First user to sign up becomes admin, everyone after is staff.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name, role)
  values (
    new.id, new.email,
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)),
    case when (select count(*) from public.profiles) = 0 then 'admin' else 'staff' end
  );
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Prevent users from promoting themselves
create or replace function public.protect_profile_role() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if (new.role <> old.role or new.is_active <> old.is_active) and not public.is_admin() then
    raise exception 'Only an admin can change role or active status';
  end if;
  return new;
end $$;

create trigger trg_profiles_protect before update on public.profiles
  for each row execute function public.protect_profile_role();

-- ---------------------------------------------------------------------
-- Partners / investments
-- ---------------------------------------------------------------------
create table public.partners (
  id                 uuid primary key default gen_random_uuid(),
  name               text not null,
  email              text,
  phone              text,
  ownership_percent  numeric(5,2) not null default 0 check (ownership_percent between 0 and 100),
  notes              text,
  is_active          boolean not null default true,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

create table public.investments (
  id              uuid primary key default gen_random_uuid(),
  investment_code text unique not null default ('INV-' || lpad(nextval('seq_investment')::text, 4, '0')),
  partner_id      uuid not null references public.partners(id) on delete restrict,
  investment_date date not null default current_date,
  amount          numeric(14,2) not null check (amount > 0),
  investment_type text not null check (investment_type in ('Initial Capital','Additional Investment','Loan','Other')),
  payment_method  text check (payment_method in ('Cash','UPI','Bank Transfer','Card','Other')),
  notes           text,
  created_by      uuid references public.profiles(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index idx_investments_partner on public.investments(partner_id);
create index idx_investments_date    on public.investments(investment_date);

-- Partner ledger: money in (investment) / money out (withdrawal)
create table public.partner_transactions (
  id               uuid primary key default gen_random_uuid(),
  partner_id       uuid not null references public.partners(id) on delete restrict,
  investment_id    uuid references public.investments(id) on delete cascade,
  transaction_date date not null default current_date,
  transaction_type text not null check (transaction_type in ('Investment','Withdrawal','Profit Share','Adjustment')),
  amount_in        numeric(14,2) not null default 0 check (amount_in  >= 0),
  amount_out       numeric(14,2) not null default 0 check (amount_out >= 0),
  notes            text,
  created_by       uuid references public.profiles(id),
  created_at       timestamptz not null default now(),
  check (amount_in > 0 or amount_out > 0)
);
create index idx_ptx_partner_date on public.partner_transactions(partner_id, transaction_date);

-- ---------------------------------------------------------------------
-- Customers
-- ---------------------------------------------------------------------
create table public.customers (
  id               uuid primary key default gen_random_uuid(),
  customer_code    text unique not null default ('CUST-' || lpad(nextval('seq_customer')::text, 4, '0')),
  name             text not null,
  phone            text,
  email            text,
  billing_address  text,
  shipping_address text,
  gstin            text,
  customer_type    text not null default 'Direct Customer'
                   check (customer_type in ('Direct Customer','Retailer','Distributor','Doctor','Other')),
  notes            text,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index idx_customers_name  on public.customers(lower(name));
create index idx_customers_phone on public.customers(phone);

-- ---------------------------------------------------------------------
-- Categories / products / batches
-- ---------------------------------------------------------------------
create table public.categories (
  id          uuid primary key default gen_random_uuid(),
  name        text not null unique,
  description text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table public.products (
  id             uuid primary key default gen_random_uuid(),
  product_code   text unique not null default ('PRD-' || lpad(nextval('seq_product')::text, 4, '0')),
  name           text not null,
  sku            text unique not null,
  category_id    uuid references public.categories(id) on delete set null,
  description    text,
  mrp            numeric(12,2) not null default 0 check (mrp >= 0),
  selling_price  numeric(12,2) not null default 0 check (selling_price >= 0),
  cost_price     numeric(12,2) not null default 0 check (cost_price >= 0),
  gst_percent    numeric(5,2)  not null default 18 check (gst_percent between 0 and 100),
  hsn_code       text,
  minimum_stock  integer not null default 0 check (minimum_stock >= 0),
  status         text not null default 'active' check (status in ('active','inactive')),
  image_path     text,                         -- Supabase Storage path
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index idx_products_name     on public.products(lower(name));
create index idx_products_category on public.products(category_id);

create table public.product_batches (
  id                  uuid primary key default gen_random_uuid(),
  batch_number        text not null,
  product_id          uuid not null references public.products(id) on delete restrict,
  manufacturing_date  date,
  expiry_date         date,
  quantity_produced   integer not null default 0 check (quantity_produced >= 0),
  quantity_remaining  integer not null default 0 check (quantity_remaining >= 0),
  manufacturing_cost  numeric(14,2) not null default 0 check (manufacturing_cost >= 0),
  cost_per_unit       numeric(12,2) not null default 0 check (cost_per_unit >= 0),
  manufacturer        text,
  notes               text,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  unique (product_id, batch_number)
);
create index idx_batches_product on public.product_batches(product_id);
create index idx_batches_expiry  on public.product_batches(expiry_date);

-- ---------------------------------------------------------------------
-- Inventory ledger (stock is NEVER edited directly; it is the sum of rows)
-- quantity is signed: + adds stock, - removes stock
-- ---------------------------------------------------------------------
create table public.inventory_transactions (
  id               uuid primary key default gen_random_uuid(),
  product_id       uuid not null references public.products(id) on delete restrict,
  batch_id         uuid references public.product_batches(id) on delete restrict,
  transaction_type text not null check (transaction_type in
                   ('Opening Stock','Stock In','Sale','Return','Damage','Adjustment','Manufacturing','Other')),
  quantity         integer not null check (quantity <> 0),
  unit_cost        numeric(12,2) not null default 0 check (unit_cost >= 0),
  reference_type   text,            -- 'sale' | 'manufacturing' | 'manual'
  reference_id     uuid,
  notes            text,
  created_by       uuid references public.profiles(id),
  created_at       timestamptz not null default now(),
  check (
    (transaction_type in ('Opening Stock','Stock In','Manufacturing') and quantity > 0) or
    (transaction_type in ('Sale','Damage') and quantity < 0) or
    transaction_type in ('Return','Adjustment','Other')
  )
);
create index idx_invtx_product_date on public.inventory_transactions(product_id, created_at desc);
create index idx_invtx_batch         on public.inventory_transactions(batch_id);
create index idx_invtx_reference     on public.inventory_transactions(reference_type, reference_id);

-- Keep batch.quantity_remaining in sync and block negative batch stock
create or replace function public.sync_batch_remaining() returns trigger
language plpgsql as $$
begin
  if new.batch_id is not null then
    update public.product_batches
       set quantity_remaining = quantity_remaining + new.quantity
     where id = new.batch_id;      -- CHECK (>= 0) rejects overselling a batch
  end if;
  return new;
end $$;

create trigger trg_invtx_sync after insert on public.inventory_transactions
  for each row execute function public.sync_batch_remaining();

-- ---------------------------------------------------------------------
-- Manufacturing
-- ---------------------------------------------------------------------
create table public.manufacturing_batches (
  id                 uuid primary key default gen_random_uuid(),
  production_code    text unique not null default ('PROD-' || lpad(nextval('seq_production')::text, 4, '0')),
  product_id         uuid not null references public.products(id) on delete restrict,
  batch_number       text not null,
  manufacturer       text,
  manufacturing_date date not null default current_date,
  expiry_date        date,
  quantity_produced  integer not null check (quantity_produced > 0),
  manufacturing_cost numeric(14,2) not null default 0 check (manufacturing_cost >= 0),
  packaging_cost     numeric(14,2) not null default 0 check (packaging_cost >= 0),
  shipping_cost      numeric(14,2) not null default 0 check (shipping_cost >= 0),
  other_cost         numeric(14,2) not null default 0 check (other_cost >= 0),
  total_batch_cost   numeric(14,2) generated always as
                     (manufacturing_cost + packaging_cost + shipping_cost + other_cost) stored,
  cost_per_unit      numeric(12,2) generated always as
                     (round((manufacturing_cost + packaging_cost + shipping_cost + other_cost) / quantity_produced, 2)) stored,
  status             text not null default 'planned' check (status in ('planned','completed','cancelled')),
  product_batch_id   uuid references public.product_batches(id),
  notes              text,
  created_by         uuid references public.profiles(id),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  unique (product_id, batch_number)
);
create index idx_mfg_product on public.manufacturing_batches(product_id);
create index idx_mfg_date    on public.manufacturing_batches(manufacturing_date);

-- When production is completed: create the batch and add finished goods to stock.
create or replace function public.complete_manufacturing() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_batch uuid;
begin
  if new.status = 'completed' and (tg_op = 'INSERT' or old.status <> 'completed') then
    insert into public.product_batches
      (batch_number, product_id, manufacturing_date, expiry_date, quantity_produced,
       quantity_remaining, manufacturing_cost, cost_per_unit, manufacturer, notes)
    values
      (new.batch_number, new.product_id, new.manufacturing_date, new.expiry_date, new.quantity_produced,
       0, new.total_batch_cost, new.cost_per_unit, new.manufacturer, new.notes)
    returning id into v_batch;

    insert into public.inventory_transactions
      (product_id, batch_id, transaction_type, quantity, unit_cost, reference_type, reference_id, notes, created_by)
    values
      (new.product_id, v_batch, 'Manufacturing', new.quantity_produced, new.cost_per_unit,
       'manufacturing', new.id, 'Production ' || new.production_code, new.created_by);

    update public.manufacturing_batches set product_batch_id = v_batch where id = new.id;
  end if;
  return null;
end $$;

create trigger trg_mfg_complete after insert or update on public.manufacturing_batches
  for each row execute function public.complete_manufacturing();

-- ---------------------------------------------------------------------
-- Sales / invoices
-- ---------------------------------------------------------------------
create table public.invoice_counters (
  year        integer primary key,
  last_number integer not null default 0
);

-- Atomic, gap-free-per-transaction invoice numbers: FORMA-2026-0001
create or replace function public.next_invoice_number(p_date date default current_date)
returns text language plpgsql security definer set search_path = public as $$
declare
  v_year   integer := extract(year from p_date);
  v_prefix text;
  v_n      integer;
begin
  select coalesce(value #>> '{}', 'FORMA') into v_prefix from public.settings where key = 'invoice_prefix';
  v_prefix := coalesce(v_prefix, 'FORMA');
  insert into public.invoice_counters (year, last_number) values (v_year, 1)
    on conflict (year) do update set last_number = invoice_counters.last_number + 1
    returning last_number into v_n;
  return v_prefix || '-' || v_year || '-' || lpad(v_n::text, 4, '0');
end $$;

create table public.sales (
  id              uuid primary key default gen_random_uuid(),
  customer_id     uuid not null references public.customers(id) on delete restrict,
  sale_date       date not null default current_date,
  payment_method  text not null default 'Cash' check (payment_method in ('Cash','UPI','Bank Transfer','Card','Other')),
  payment_status  text not null default 'Paid' check (payment_status in ('Paid','Partially Paid','Pending')),
  subtotal        numeric(14,2) not null default 0 check (subtotal >= 0),
  discount_total  numeric(14,2) not null default 0 check (discount_total >= 0),
  taxable_amount  numeric(14,2) not null default 0 check (taxable_amount >= 0),
  gst_total       numeric(14,2) not null default 0 check (gst_total >= 0),
  other_charges   numeric(14,2) not null default 0 check (other_charges >= 0),
  grand_total     numeric(14,2) not null default 0 check (grand_total >= 0),
  amount_paid     numeric(14,2) not null default 0 check (amount_paid >= 0),
  cogs_total      numeric(14,2) not null default 0 check (cogs_total >= 0),
  notes           text,
  created_by      uuid references public.profiles(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  check (amount_paid <= grand_total)
);
create index idx_sales_customer on public.sales(customer_id);
create index idx_sales_date     on public.sales(sale_date desc);
create index idx_sales_status   on public.sales(payment_status);

create table public.sale_items (
  id             uuid primary key default gen_random_uuid(),
  sale_id        uuid not null references public.sales(id) on delete cascade,
  product_id     uuid not null references public.products(id) on delete restrict,
  batch_id       uuid references public.product_batches(id) on delete restrict,
  quantity       integer not null check (quantity > 0),
  rate           numeric(12,2) not null check (rate >= 0),
  discount       numeric(12,2) not null default 0 check (discount >= 0),   -- absolute amount on the line
  gst_percent    numeric(5,2)  not null default 0 check (gst_percent between 0 and 100),
  gst_amount     numeric(12,2) not null default 0 check (gst_amount >= 0),
  line_total     numeric(14,2) not null default 0 check (line_total >= 0),
  unit_cost      numeric(12,2) not null default 0 check (unit_cost >= 0),   -- snapshot for COGS
  created_at     timestamptz not null default now(),
  check (discount <= quantity * rate)
);
create index idx_sale_items_sale    on public.sale_items(sale_id);
create index idx_sale_items_product on public.sale_items(product_id);

create table public.invoices (
  id             uuid primary key default gen_random_uuid(),
  invoice_number text not null unique,
  sale_id        uuid not null unique references public.sales(id) on delete cascade,
  customer_id    uuid not null references public.customers(id) on delete restrict,
  invoice_date   date not null default current_date,
  due_date       date,
  pdf_path       text,                         -- optional stored PDF
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index idx_invoices_customer on public.invoices(customer_id);
create index idx_invoices_date     on public.invoices(invoice_date desc);

-- ---------------------------------------------------------------------
-- Expenses (operating expenses ONLY - investments live elsewhere)
-- ---------------------------------------------------------------------
create table public.expense_categories (
  id         uuid primary key default gen_random_uuid(),
  name       text not null unique,
  created_at timestamptz not null default now()
);

create table public.expenses (
  id              uuid primary key default gen_random_uuid(),
  expense_code    text unique not null default ('EXP-' || lpad(nextval('seq_expense')::text, 5, '0')),
  expense_date    date not null default current_date,
  category_id     uuid not null references public.expense_categories(id) on delete restrict,
  description     text not null,
  amount          numeric(14,2) not null check (amount > 0),
  payment_method  text check (payment_method in ('Cash','UPI','Bank Transfer','Card','Other')),
  vendor          text,
  notes           text,
  receipt_path    text,
  created_by      uuid references public.profiles(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index idx_expenses_date     on public.expenses(expense_date desc);
create index idx_expenses_category on public.expenses(category_id);

-- ---------------------------------------------------------------------
-- Settings (key / jsonb value) and attachments
-- ---------------------------------------------------------------------
create table public.settings (
  key        text primary key,
  value      jsonb not null,
  updated_at timestamptz not null default now()
);

create table public.attachments (
  id          uuid primary key default gen_random_uuid(),
  bucket      text not null,
  path        text not null,
  file_name   text,
  mime_type   text,
  size_bytes  bigint,
  entity_type text,                    -- 'product' | 'expense' | 'invoice' | ...
  entity_id   uuid,
  uploaded_by uuid references public.profiles(id),
  created_at  timestamptz not null default now(),
  unique (bucket, path)
);
create index idx_attachments_entity on public.attachments(entity_type, entity_id);

-- ---------------------------------------------------------------------
-- updated_at triggers
-- ---------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array[
    'profiles','partners','investments','customers','categories','products',
    'product_batches','manufacturing_batches','sales','invoices','expenses','settings'
  ] loop
    execute format('create trigger trg_%1$s_updated before update on public.%1$s
                    for each row execute function public.set_updated_at()', t);
  end loop;
end $$;

-- ---------------------------------------------------------------------
-- Reporting views
-- ---------------------------------------------------------------------
create or replace view public.v_product_stock with (security_invoker = true) as
select p.id as product_id,
       coalesce(sum(t.quantity), 0)::integer                       as current_stock,
       coalesce(sum(t.quantity * t.unit_cost), 0)::numeric(14,2)   as stock_value,
       (coalesce(sum(t.quantity), 0) <= p.minimum_stock)           as is_low_stock
from public.products p
left join public.inventory_transactions t on t.product_id = p.id
group by p.id;

create or replace view public.v_partner_balances with (security_invoker = true) as
select pa.id as partner_id, pa.name,
       coalesce(sum(pt.amount_in),  0) as money_in,
       coalesce(sum(pt.amount_out), 0) as money_out,
       coalesce(sum(pt.amount_in - pt.amount_out), 0) as balance
from public.partners pa
left join public.partner_transactions pt on pt.partner_id = pa.id
group by pa.id, pa.name;

-- ---------------------------------------------------------------------
-- Investment -> partner ledger (investment is capital, never an expense)
-- ---------------------------------------------------------------------
create or replace function public.investment_to_ledger() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.partner_transactions
    (partner_id, investment_id, transaction_date, transaction_type, amount_in, notes, created_by)
  values (new.partner_id, new.id, new.investment_date, 'Investment', new.amount,
          new.investment_type, new.created_by);
  return new;
end $$;

create trigger trg_investment_ledger after insert on public.investments
  for each row execute function public.investment_to_ledger();

-- ---------------------------------------------------------------------
-- ROW LEVEL SECURITY
--   admin : everything
--   staff : customers, products, categories, batches, inventory, sales,
--           sale_items, invoices (no delete), read-only on settings
--   admin only: investments, partners, partner_transactions, manufacturing,
--               expenses, expense_categories, settings writes
-- ---------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array[
    'profiles','partners','investments','partner_transactions','customers','categories','products',
    'product_batches','inventory_transactions','manufacturing_batches','sales','sale_items','invoices',
    'invoice_counters','expenses','expense_categories','settings','attachments'
  ] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('create policy "admin all" on public.%I for all to authenticated
                    using (public.is_admin()) with check (public.is_admin())', t);
  end loop;

  -- staff: read + write
  foreach t in array array['customers','categories','products','product_batches',
                           'inventory_transactions','sales','sale_items','invoices','attachments'] loop
    execute format('create policy "staff read"   on public.%I for select to authenticated using (public.is_staff_or_admin())', t);
    execute format('create policy "staff insert" on public.%I for insert to authenticated with check (public.is_staff_or_admin())', t);
  end loop;
  foreach t in array array['customers','categories','products','product_batches','sales','invoices'] loop
    execute format('create policy "staff update" on public.%I for update to authenticated
                    using (public.is_staff_or_admin()) with check (public.is_staff_or_admin())', t);
  end loop;
end $$;

-- staff read-only access to things needed for invoices / forms
create policy "staff read settings" on public.settings for select to authenticated using (public.is_staff_or_admin());
create policy "staff read expense cats" on public.expense_categories for select to authenticated using (public.is_staff_or_admin());

-- profiles: everyone reads own row, updates own name/phone (role guarded by trigger)
create policy "read own profile"   on public.profiles for select to authenticated using (id = auth.uid());
create policy "update own profile" on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- ---------------------------------------------------------------------
-- Storage buckets (private) + policies
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public) values
  ('product-images','product-images', false),
  ('receipts','receipts', false),
  ('company','company', false),
  ('invoices','invoices', false),
  ('attachments','attachments', false)
on conflict (id) do nothing;

create policy "staff read files" on storage.objects for select to authenticated
  using (bucket_id in ('product-images','company','invoices','attachments') and public.is_staff_or_admin());
create policy "staff write product images" on storage.objects for insert to authenticated
  with check (bucket_id in ('product-images','invoices','attachments') and public.is_staff_or_admin());
create policy "admin all files" on storage.objects for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------
-- Seed: default categories + settings
-- ---------------------------------------------------------------------
insert into public.expense_categories (name) values
 ('Manufacturing'),('Packaging'),('Marketing'),('Advertising'),('Shipping'),('Website'),
 ('Software'),('Salary'),('Office'),('Samples'),('Influencer'),('Professional Fees'),('Miscellaneous')
on conflict do nothing;

insert into public.categories (name) values ('Face Care'),('Skin Care'),('Body Care'),('Hair Care')
on conflict do nothing;

insert into public.settings (key, value) values
 ('company',        '{"name":"Forma Cosmetics","address":"","phone":"","email":"","website":"","gstin":"","logo_path":""}'),
 ('invoice_prefix', '"FORMA"'),
 ('invoice',        '{"terms":"","footer":"","bank_details":"","signature_path":""}'),
 ('tax',            '{"default_gst_percent":18,"allow_negative_stock":false}'),
 ('low_stock_default','10')
on conflict do nothing;

-- Next: run supabase/functions.sql (sales, invoices, reports, views).
