-- =====================================================================
-- FORMA - business functions (run AFTER schema.sql)
-- create_sale, record_payment, void_sale, dashboard / P&L reporting, demo reset
-- =====================================================================

-- ---------------------------------------------------------------------
-- Internal helper: writes one sale line + its stock movement
-- ---------------------------------------------------------------------
create or replace function public._add_sale_line(
  p_sale uuid, p_product uuid, p_batch uuid, p_qty int, p_rate numeric,
  p_disc numeric, p_gst numeric, p_unit_cost numeric, p_user uuid)
returns table(gross numeric, disc numeric, taxable numeric, gst_amt numeric, cogs numeric)
language plpgsql as $$
declare v_gross numeric; v_taxable numeric; v_gst numeric;
begin
  v_gross   := round(p_qty * p_rate, 2);
  v_taxable := v_gross - p_disc;
  v_gst     := round(v_taxable * p_gst / 100, 2);

  insert into public.sale_items
    (sale_id, product_id, batch_id, quantity, rate, discount, gst_percent, gst_amount, line_total, unit_cost)
  values (p_sale, p_product, p_batch, p_qty, p_rate, p_disc, p_gst, v_gst, v_taxable + v_gst, p_unit_cost);

  insert into public.inventory_transactions
    (product_id, batch_id, transaction_type, quantity, unit_cost, reference_type, reference_id, created_by)
  values (p_product, p_batch, 'Sale', -p_qty, p_unit_cost, 'sale', p_sale, p_user);

  return query select v_gross, p_disc, v_taxable, v_gst, round(p_qty * p_unit_cost, 2);
end $$;

-- ---------------------------------------------------------------------
-- create_sale: ONE transaction -> sale, items, stock deduction, COGS, invoice
-- p_items: [{product_id, batch_id?, quantity, rate, discount?, gst_percent?}]
--   discount = absolute amount for that line
-- If batch_id is omitted, stock is taken first-expiry-first-out.
-- ---------------------------------------------------------------------
create or replace function public.create_sale(
  p_customer_id uuid, p_sale_date date, p_payment_method text, p_payment_status text,
  p_other_charges numeric, p_amount_paid numeric, p_notes text, p_items jsonb,
  p_allow_negative boolean default false)
returns jsonb language plpgsql as $$
declare
  v_user uuid := auth.uid();
  v_sale uuid; v_item jsonb; v_prod public.products%rowtype; v_batch public.product_batches%rowtype;
  v_explicit uuid; v_qty int; v_rate numeric; v_disc numeric; v_gst numeric;
  v_left int; v_take int; v_disc_left numeric; v_piece_disc numeric; v_stock int;
  v_sub numeric := 0; v_dis numeric := 0; v_tax numeric := 0; v_gsttot numeric := 0; v_cogs numeric := 0;
  v_other numeric := coalesce(p_other_charges, 0);
  v_grand numeric; v_paid numeric; v_inv_no text; v_inv uuid; r record;
begin
  if not public.is_staff_or_admin() then raise exception 'You do not have permission to create sales'; end if;
  if not exists (select 1 from public.customers where id = p_customer_id) then raise exception 'Invalid customer'; end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'Add at least one product';
  end if;
  if v_other < 0 then raise exception 'Other charges cannot be negative'; end if;
  if p_allow_negative and not public.is_admin() then raise exception 'Only an admin can sell above available stock'; end if;
  if p_payment_method not in ('Cash','UPI','Bank Transfer','Card','Other') then raise exception 'Invalid payment method'; end if;
  if p_payment_status not in ('Paid','Partially Paid','Pending') then raise exception 'Invalid payment status'; end if;

  insert into public.sales (customer_id, sale_date, payment_method, payment_status, other_charges, notes, created_by)
  values (p_customer_id, coalesce(p_sale_date, current_date), p_payment_method, p_payment_status, v_other, p_notes, v_user)
  returning id into v_sale;

  for v_item in select * from jsonb_array_elements(p_items) loop
    select * into v_prod from public.products where id = nullif(v_item->>'product_id','')::uuid for update;
    if not found then raise exception 'Invalid product'; end if;

    v_qty  := coalesce((v_item->>'quantity')::int, 0);
    v_rate := coalesce((v_item->>'rate')::numeric, -1);
    v_disc := coalesce((v_item->>'discount')::numeric, 0);
    v_gst  := coalesce((v_item->>'gst_percent')::numeric, v_prod.gst_percent);
    v_explicit := nullif(v_item->>'batch_id','')::uuid;

    if v_qty <= 0 then raise exception 'Quantity for % must be greater than zero', v_prod.name; end if;
    if v_rate < 0 then raise exception 'Invalid price for %', v_prod.name; end if;
    if v_disc < 0 or v_disc > v_qty * v_rate then raise exception 'Invalid discount for %', v_prod.name; end if;
    if v_gst < 0 or v_gst > 100 then raise exception 'Invalid GST for %', v_prod.name; end if;

    select coalesce(sum(quantity), 0) into v_stock from public.inventory_transactions where product_id = v_prod.id;
    if v_qty > v_stock and not p_allow_negative then
      raise exception 'Not enough stock for %: % available, % requested', v_prod.name, v_stock, v_qty;
    end if;

    v_left := v_qty; v_disc_left := v_disc;

    for v_batch in
      select * from public.product_batches
       where product_id = v_prod.id and quantity_remaining > 0
         and (v_explicit is null or id = v_explicit)
         and (expiry_date is null or expiry_date >= coalesce(p_sale_date, current_date))
       order by expiry_date nulls last, created_at
       for update
    loop
      exit when v_left = 0;
      v_take := least(v_left, v_batch.quantity_remaining);
      v_piece_disc := least(case when v_take = v_left then v_disc_left else round(v_disc * v_take / v_qty, 2) end, round(v_take * v_rate, 2));
      select * into r from public._add_sale_line(v_sale, v_prod.id, v_batch.id, v_take, v_rate, v_piece_disc, v_gst, v_batch.cost_per_unit, v_user);
      v_sub := v_sub + r.gross; v_dis := v_dis + r.disc; v_tax := v_tax + r.taxable; v_gsttot := v_gsttot + r.gst_amt; v_cogs := v_cogs + r.cogs;
      v_left := v_left - v_take; v_disc_left := v_disc_left - v_piece_disc;
    end loop;

    if v_left > 0 then
      if v_explicit is not null and not p_allow_negative then
        raise exception 'The selected batch of % does not have enough unexpired stock', v_prod.name;
      end if;
      select * into r from public._add_sale_line(v_sale, v_prod.id, null, v_left, v_rate, v_disc_left, v_gst, v_prod.cost_price, v_user);
      v_sub := v_sub + r.gross; v_dis := v_dis + r.disc; v_tax := v_tax + r.taxable; v_gsttot := v_gsttot + r.gst_amt; v_cogs := v_cogs + r.cogs;
    end if;
  end loop;

  v_grand := v_tax + v_gsttot + v_other;
  v_paid := case p_payment_status
              when 'Paid' then v_grand
              when 'Pending' then 0
              else coalesce(p_amount_paid, 0) end;
  if p_payment_status = 'Partially Paid' and (v_paid <= 0 or v_paid >= v_grand) then
    raise exception 'For a partial payment, enter an amount greater than 0 and less than the total (%)', v_grand;
  end if;

  update public.sales set subtotal = v_sub, discount_total = v_dis, taxable_amount = v_tax, gst_total = v_gsttot,
         grand_total = v_grand, amount_paid = v_paid, cogs_total = v_cogs
   where id = v_sale;

  v_inv_no := public.next_invoice_number(coalesce(p_sale_date, current_date));
  insert into public.invoices (invoice_number, sale_id, customer_id, invoice_date)
  values (v_inv_no, v_sale, p_customer_id, coalesce(p_sale_date, current_date))
  returning id into v_inv;

  return jsonb_build_object('sale_id', v_sale, 'invoice_id', v_inv, 'invoice_number', v_inv_no, 'grand_total', v_grand);
end $$;

-- ---------------------------------------------------------------------
-- record_payment: add a payment against a sale
-- ---------------------------------------------------------------------
create or replace function public.record_payment(p_sale uuid, p_amount numeric)
returns void language plpgsql as $$
declare s public.sales%rowtype;
begin
  if not public.is_staff_or_admin() then raise exception 'Not allowed'; end if;
  select * into s from public.sales where id = p_sale for update;
  if not found then raise exception 'Sale not found'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Enter an amount greater than zero'; end if;
  if s.amount_paid + p_amount > s.grand_total then
    raise exception 'Payment exceeds the pending amount of %', s.grand_total - s.amount_paid;
  end if;
  update public.sales
     set amount_paid = amount_paid + p_amount,
         payment_status = case when amount_paid + p_amount = grand_total then 'Paid' else 'Partially Paid' end
   where id = p_sale;
end $$;

-- ---------------------------------------------------------------------
-- void_sale (admin): returns stock to inventory and removes the sale + invoice
-- ---------------------------------------------------------------------
create or replace function public.void_sale(p_sale uuid)
returns void language plpgsql as $$
declare it record; v_no text;
begin
  if not public.is_admin() then raise exception 'Only an admin can delete a sale'; end if;
  select invoice_number into v_no from public.invoices where sale_id = p_sale;
  for it in select * from public.sale_items where sale_id = p_sale loop
    insert into public.inventory_transactions
      (product_id, batch_id, transaction_type, quantity, unit_cost, reference_type, reference_id, notes, created_by)
    values (it.product_id, it.batch_id, 'Return', it.quantity, it.unit_cost, 'sale', p_sale,
            'Voided ' || coalesce(v_no, 'sale'), auth.uid());
  end loop;
  delete from public.sales where id = p_sale;
end $$;

-- ---------------------------------------------------------------------
-- Dashboard / Profit & Loss
--   Revenue  = taxable sales + other charges (GST collected is NOT revenue)
--   COGS     = unit cost snapshot x quantity sold
--   Net      = Revenue - COGS - Operating expenses  (investments never included)
-- ---------------------------------------------------------------------
create or replace function public.dashboard_summary(p_from date, p_to date)
returns jsonb language sql stable as $$
  select jsonb_build_object(
    'revenue',  s.rev, 'cogs', s.cogs, 'gst', s.gst, 'billed', s.billed, 'paid', s.paid,
    'gross_profit', s.rev - s.cogs,
    'expenses', e.exp,
    'net_profit', s.rev - s.cogs - e.exp,
    'units_sold', u.units,
    'orders', s.orders,
    'total_investment', i.inv,
    'inventory_value', st.val,
    'low_stock', st.low)
  from
   (select coalesce(sum(taxable_amount + other_charges),0) rev, coalesce(sum(cogs_total),0) cogs,
           coalesce(sum(gst_total),0) gst, coalesce(sum(grand_total),0) billed, coalesce(sum(amount_paid),0) paid,
           count(*) orders
      from public.sales where sale_date between p_from and p_to) s,
   (select coalesce(sum(amount),0) exp from public.expenses where expense_date between p_from and p_to) e,
   (select coalesce(sum(si.quantity),0) units from public.sale_items si
      join public.sales sa on sa.id = si.sale_id where sa.sale_date between p_from and p_to) u,
   (select coalesce(sum(amount),0) inv from public.investments) i,
   (select coalesce(sum(vs.stock_value),0) val,
           count(*) filter (where vs.is_low_stock and p.status = 'active') low
      from public.v_product_stock vs join public.products p on p.id = vs.product_id) st;
$$;

create or replace function public.revenue_expense_series(p_from date, p_to date, p_group text default 'month')
returns table(period date, revenue numeric, cogs numeric, expenses numeric)
language plpgsql stable as $$
begin
  if p_group not in ('day','week','month','quarter','year') then raise exception 'Invalid grouping'; end if;
  return query
  select p.period,
    coalesce((select sum(s.taxable_amount + s.other_charges) from public.sales s
               where s.sale_date between p_from and p_to and date_trunc(p_group, s.sale_date)::date = p.period), 0),
    coalesce((select sum(s.cogs_total) from public.sales s
               where s.sale_date between p_from and p_to and date_trunc(p_group, s.sale_date)::date = p.period), 0),
    coalesce((select sum(x.amount) from public.expenses x
               where x.expense_date between p_from and p_to and date_trunc(p_group, x.expense_date)::date = p.period), 0)
  from (select generate_series(date_trunc(p_group, p_from)::date, date_trunc(p_group, p_to)::date,
          case p_group when 'quarter' then interval '3 months' else ('1 ' || p_group)::interval end)::date as period) p
  order by p.period;
end $$;

create or replace function public.top_products(p_from date, p_to date, p_limit int default 5)
returns table(product_id uuid, name text, units bigint, revenue numeric, cogs numeric)
language sql stable as $$
  select p.id, p.name, sum(si.quantity)::bigint, sum(si.line_total - si.gst_amount),
         sum(si.quantity * si.unit_cost)
    from public.sale_items si
    join public.sales s on s.id = si.sale_id
    join public.products p on p.id = si.product_id
   where s.sale_date between p_from and p_to
   group by p.id, p.name order by 4 desc limit p_limit;
$$;

create or replace function public.product_stats(p_product uuid)
returns jsonb language sql stable as $$
  select jsonb_build_object(
    'units', coalesce(sum(si.quantity),0),
    'revenue', coalesce(sum(si.line_total - si.gst_amount),0),
    'cogs', coalesce(sum(si.quantity * si.unit_cost),0),
    'profit', coalesce(sum(si.line_total - si.gst_amount - si.quantity * si.unit_cost),0))
  from public.sale_items si where si.product_id = p_product;
$$;

create or replace function public.expense_breakdown(p_from date, p_to date)
returns table(category text, total numeric)
language sql stable as $$
  select c.name, sum(e.amount) from public.expenses e
    join public.expense_categories c on c.id = e.category_id
   where e.expense_date between p_from and p_to group by c.name order by 2 desc;
$$;

-- ---------------------------------------------------------------------
-- Demo data reset (admin). The app records the ids it created.
-- p_ids: {customers:[], products:[], partners:[], investments:[], expenses:[], sales:[], manufacturing:[]}
-- ---------------------------------------------------------------------
create or replace function public.reset_demo_data(p_ids jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare
  f_prod uuid[]  := array(select jsonb_array_elements_text(coalesce(p_ids->'products','[]'))::uuid);
  f_cust uuid[]  := array(select jsonb_array_elements_text(coalesce(p_ids->'customers','[]'))::uuid);
  f_part uuid[]  := array(select jsonb_array_elements_text(coalesce(p_ids->'partners','[]'))::uuid);
  f_inv  uuid[]  := array(select jsonb_array_elements_text(coalesce(p_ids->'investments','[]'))::uuid);
  f_exp  uuid[]  := array(select jsonb_array_elements_text(coalesce(p_ids->'expenses','[]'))::uuid);
  f_sale uuid[]  := array(select jsonb_array_elements_text(coalesce(p_ids->'sales','[]'))::uuid);
  f_mfg  uuid[]  := array(select jsonb_array_elements_text(coalesce(p_ids->'manufacturing','[]'))::uuid);
begin
  if not public.is_admin() then raise exception 'Only an admin can reset demo data'; end if;
  delete from public.sales where id = any(f_sale);                       -- items + invoices cascade
  delete from public.inventory_transactions where product_id = any(f_prod);
  delete from public.manufacturing_batches where id = any(f_mfg) or product_id = any(f_prod);
  delete from public.product_batches where product_id = any(f_prod);
  delete from public.expenses where id = any(f_exp);
  delete from public.partner_transactions where partner_id = any(f_part);
  delete from public.investments where id = any(f_inv) or partner_id = any(f_part);
  delete from public.partners where id = any(f_part);
  delete from public.customers where id = any(f_cust);
  delete from public.products where id = any(f_prod);
  if not exists (select 1 from public.invoices) then delete from public.invoice_counters; end if;
end $$;

-- ---------------------------------------------------------------------
-- Keep partner ledger in sync when an investment is edited
-- ---------------------------------------------------------------------
create or replace function public.investment_ledger_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.partner_transactions
     set partner_id = new.partner_id, transaction_date = new.investment_date,
         amount_in = new.amount, notes = new.investment_type
   where investment_id = new.id;
  return new;
end $$;
drop trigger if exists trg_investment_ledger_upd on public.investments;
create trigger trg_investment_ledger_upd after update on public.investments
  for each row execute function public.investment_ledger_update();

-- ---------------------------------------------------------------------
-- Read views used by the screens (security_invoker => RLS still applies)
-- ---------------------------------------------------------------------
create or replace view public.v_products with (security_invoker = true) as
select p.*, c.name as category_name,
       coalesce(s.current_stock, 0) as current_stock,
       coalesce(s.stock_value, 0)   as stock_value,
       coalesce(s.is_low_stock, false) as is_low_stock
from public.products p
left join public.categories c on c.id = p.category_id
left join public.v_product_stock s on s.product_id = p.id;

create or replace view public.v_batches with (security_invoker = true) as
select b.*, p.name as product_name, p.sku,
       case when b.expiry_date is null then 'Active'
            when b.expiry_date < current_date then 'Expired'
            when b.expiry_date <= current_date + 90 then 'Expiring Soon'
            else 'Active' end as status
from public.product_batches b join public.products p on p.id = b.product_id;

create or replace view public.v_stock_history with (security_invoker = true) as
select t.*, p.name as product_name, p.sku, b.batch_number
from public.inventory_transactions t
join public.products p on p.id = t.product_id
left join public.product_batches b on b.id = t.batch_id;

create or replace view public.v_customers with (security_invoker = true) as
select c.*,
  (select count(*) from public.sales s where s.customer_id = c.id) as total_orders,
  (select coalesce(sum(grand_total),0) from public.sales s where s.customer_id = c.id) as total_purchase,
  (select coalesce(sum(amount_paid),0) from public.sales s where s.customer_id = c.id) as total_paid,
  (select coalesce(sum(grand_total - amount_paid),0) from public.sales s where s.customer_id = c.id) as total_pending
from public.customers c;

create or replace view public.v_sales with (security_invoker = true) as
select s.*, c.name as customer_name, i.invoice_number, i.id as invoice_id,
       (s.grand_total - s.amount_paid) as pending_amount
from public.sales s
join public.customers c on c.id = s.customer_id
left join public.invoices i on i.sale_id = s.id;

create or replace view public.v_invoices with (security_invoker = true) as
select i.*, c.name as customer_name, s.grand_total, s.amount_paid, s.payment_status, s.payment_method,
       (s.grand_total - s.amount_paid) as pending_amount
from public.invoices i
join public.sales s on s.id = i.sale_id
join public.customers c on c.id = i.customer_id;

create or replace view public.v_manufacturing with (security_invoker = true) as
select m.*, p.name as product_name from public.manufacturing_batches m join public.products p on p.id = m.product_id;

create or replace view public.v_expenses with (security_invoker = true) as
select e.*, c.name as category_name from public.expenses e join public.expense_categories c on c.id = e.category_id;

create or replace view public.v_investments with (security_invoker = true) as
select i.*, p.name as partner_name from public.investments i join public.partners p on p.id = i.partner_id;

create or replace view public.v_partners with (security_invoker = true) as
select p.*,
  coalesce((select sum(amount) from public.investments i where i.partner_id = p.id and i.investment_type = 'Initial Capital'),0) as initial_investment,
  coalesce((select sum(amount_in) from public.partner_transactions t where t.partner_id = p.id),0)  as total_investment,
  coalesce((select sum(amount_out) from public.partner_transactions t where t.partner_id = p.id),0) as withdrawals,
  coalesce((select sum(amount_in - amount_out) from public.partner_transactions t where t.partner_id = p.id),0) as current_balance
from public.partners p;

create or replace view public.v_partner_ledger with (security_invoker = true) as
select t.*, p.name as partner_name from public.partner_transactions t join public.partners p on p.id = t.partner_id;
